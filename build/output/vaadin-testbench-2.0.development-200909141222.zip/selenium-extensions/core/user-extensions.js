/* Selenium core extensions for Vaadin */

/* Also in IDE extensions */
function getVaadinConnector(wnd) {
	if (wnd.wrappedJSObject) {
		wnd = wnd.wrappedJSObject;
	}

	var connector = null;
	if (wnd.itmill) {
		connector = wnd.itmill;
	} else if (wnd.vaadin) {
		connector = wnd.vaadin;
	}

	return connector;
}

PageBot.prototype.locateElementByVaadin = function(tkString, inDocument) {

	var connector = getVaadinConnector(this.currentWindow);

	if (!connector) {
		// Not a toolkit application
		return null;
	}

	var parts = tkString.split("::");
	var appId = parts[0];

	try {
		var element = connector.clients[appId].getElementByPath(parts[1]);
		return element;
	} catch (exception) {
		LOG.error('an error occured when locating element for '+tkString+': ' + exception);
	}
	return null;
}

/*
 PageBot.prototype.locateElementByVaadin.is_fuzzy_match = function(
 source, target) {

 if (source.wrappedJSObject) {
 source = source.wrappedJSObject;
 }
 if (target.wrappedJSObject) {
 target = target.wrappedJSObject;
 }
 if (target == source) {
 return true;
 }

 return true;

 }

 */
Selenium.prototype.doWaitForVaadin = function(locator, value) {

	// max time to wait for toolkit to settle
	var timeout = 20000;
	var foundClientOnce = false;
	
	return Selenium.decorateFunctionWithTimeout( function() {
		var wnd = selenium.browserbot.getCurrentWindow();
		var connector = getVaadinConnector(wnd);
		if (!connector) {
			// No connector found == Not a Vaadin application so we don't need to wait
			return true;
		}
		
		var clients = connector.clients;
		if (clients) {
			foundClientOnce = true;
			for ( var client in clients) {
				if (clients[client].isActive()) {
					return false;
				}
			}
			return true;
		} else {
			if (foundClientOnce) {
				// There was a client, so probably there will be again once something has refreshed
				// This happens for instance when the theme is changed on the fly
				return false;
			}
			if (!this.VaadinWarnedNoAppFound) {
				// TODO explain what this means & what to do
					LOG.warn("No testable Vaadin applications found!");
				this.VaadinWarnedNoAppFound = true;
			}
			
			return true;
	}
}, timeout);

}

Selenium.prototype.doScroll = function(locator, scrollString) {
	var element = this.page().findElement(locator);
	element.scrollTop = scrollString;
};

Selenium.prototype.doContextmenu = function(locator) { 
     var element = this.page().findElement(locator); 
     this.page()._fireEventOnElement("contextmenu", element, 0, 0); 
}; 

Selenium.prototype.doContextmenuAt = function(locator, coordString) { 
      if (!coordString) 
    	  coordString = '2, 2'; 
      
      var element = this.page().findElement(locator); 
      var clientXY = getClientXY(element, coordString);
      this.page()._fireEventOnElement("contextmenu", element, clientXY[0], clientXY[1]); 
};

/* Add the screenCapture as an action to SeleniumIDE command overlay */
CommandBuilders.add("action", function(window){

	var result = { action: "ScreenCapture" };
	
	return{
		command: "screenCapture"
	};
});

/* Empty screenCapture command for use with export test case Vaadin */
Selenium.prototype.doScreenCapture = function(locator, value){
};
